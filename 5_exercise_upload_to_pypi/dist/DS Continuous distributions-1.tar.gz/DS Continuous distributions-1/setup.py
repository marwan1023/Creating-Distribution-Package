from setuptools import setup

setup(name='DS Continuous distributions',
      version='1',
      description='Gaussian and Binomial distributions',
      packages=['DS Continuous distributions'],
      zip_safe=False)
